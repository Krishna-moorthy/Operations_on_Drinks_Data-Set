# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 19:39:23 2018

@author:  Krishnamoorthy KBhat
"""
#Step 1. Import the necessary libraries
#
#Step 2. Import the dataset
#
#Step 3. Assign it to a variable called drinks.
import pandas as pd

"1st question"
# read drinks.csv into a DataFrame called 'drinks'
drinks = pd.read_csv('drinks.csv') 

# print the 'beer_servings' Series
drinks['beer_servings']
drinks.beer_servings
#drinks.beer_servings.describe() 
#drinks.beer_servings.mean()  

"2nd question"

# Determine which country has the highest value for 'beer_servings'
drinks[drinks.beer_servings==drinks.beer_servings.max()].country


"3rd question"

#  For each continent print the statistics for wine consumption.
drinks.groupby('continent').wine_servings.mean()
drinks.groupby('continent').wine_servings.max()
drinks.groupby('continent').wine_servings.min()


drinks.groupby('continent').mean()
drinks.groupby('continent').spirit_servings.agg(['mean'])

"4th question"
#Step 6. Print the mean alcohol consumption per continent for every column

drinks.groupby('continent').total_litres_of_pure_alcohol.mean()



"5TH QUESTION"

#  Print the mean, min and max values for spirit consumption.
drinks.describe()                   # summarize all numeric columns
drinks.spirit_servings.describe()     # summarize only the 'beer_servings' Series
drinks.spirit_servings.mean()         # only calculate the mean
drinks.spirit_servings.max()          # only calculate the max
drinks.spirit_servings.min()          # only calculate the min




